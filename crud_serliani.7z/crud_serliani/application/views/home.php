<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Halaman home</title>
</head>
<body>
	<h1>Data Mahasiswa USB</h1>

	<a href="">tambah mahasiswa</a>
	<br><br>
		<table border="1">
		<tr>
			<td>No</td>
			<td>Nama</td>
			<td>Jurusan</td>
			<td>Aksi</td>
		</tr>
		<tr>
			<td>1</td>
			<td>gustiayu</td>
			<td>teknik informatika</td>
			<td><a href="">Edit</a> | <a href="">Delete</td>
			
		</tr>
		<tr>
			<td>2</td>
			<td>mudrikayani</td>
			<td>teknik informatika</td>
			<td><a href="">Edit</a> | <a href="">Delete</td>
		</tr>
		<tr>
			<td>3</td>
			<td>yunita</td>
			<td>teknik pwk</td>
			<td><a href="">Edit</a> | <a href="">Delete</td>
		</tr>
		<tr>
			<td>4</td>
			<td>mardin</td>
			<td>teknik pwk</td>
			<td><a href="">Edit</a> | <a href="" style="">Delete</td>
		</tr>
	</table>
</body>
</html>